import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Loader2 } from "lucide-react";
import { askAI } from "@/lib/aiProvider";

export const Route = createFileRoute("/_authenticated/dashboard/calculator")({
  component: CalculatorPage,
});

type Tab = "basic" | "scientific" | "formula" | "convert";

function CalculatorPage() {
  const [tab, setTab] = useState<Tab>("basic");
  const [expr, setExpr] = useState("");
  const [result, setResult] = useState("");
  const [history, setHistory] = useState<string[]>([]);

  function press(k: string) {
    if (k === "=") { compute(); return; }
    if (k === "C") { setExpr(""); setResult(""); return; }
    if (k === "⌫") { setExpr(expr.slice(0, -1)); return; }
    setExpr(expr + k);
  }
  function compute() {
    try {
      // eslint-disable-next-line @typescript-eslint/no-implied-eval
      const r = Function(`"use strict"; const sin=Math.sin,cos=Math.cos,tan=Math.tan,log=Math.log10,ln=Math.log,sqrt=Math.sqrt,pi=Math.PI,e=Math.E; return (${expr.replace(/\^/g, "**")})`)();
      setResult(String(r));
      setHistory([`${expr} = ${r}`, ...history].slice(0, 10));
    } catch {
      setResult("Error");
    }
  }

  return (
    <div className="space-y-4">
      <div className="card-soft flex gap-1 p-1">
        {(["basic", "scientific", "formula", "convert"] as Tab[]).map((t) => (
          <button key={t} onClick={() => setTab(t)} className={`flex-1 rounded-md px-3 py-2 text-xs font-medium capitalize ${tab === t ? "bg-primary text-primary-foreground" : "hover:bg-accent"}`}>
            {t === "convert" ? "Unit Converter" : t === "formula" ? "AI Formula Helper" : t}
          </button>
        ))}
      </div>

      {(tab === "basic" || tab === "scientific") && (
        <div className="card-soft mx-auto max-w-md p-4">
          <div className="mb-3 rounded-lg bg-accent p-3 text-right">
            <div className="text-xs text-muted-foreground">{expr || "0"}</div>
            <div className="text-2xl font-bold">{result || "0"}</div>
          </div>
          <div className="grid grid-cols-4 gap-2">
            {(tab === "scientific" ? ["sin(", "cos(", "tan(", "sqrt(", "log(", "ln(", "pi", "e", "^", "(", ")", "%"] : []).map((k) => (
              <button key={k} onClick={() => press(k)} className="rounded-lg bg-accent py-2 text-xs hover:opacity-80">{k}</button>
            ))}
            {["C", "⌫", "/", "*", "7", "8", "9", "-", "4", "5", "6", "+", "1", "2", "3", "=", "0", ".", "(", ")"].map((k) => (
              <button key={k} onClick={() => press(k)} className={`rounded-lg py-3 text-sm font-semibold hover:opacity-80 ${k === "=" ? "bg-primary text-primary-foreground" : k === "C" || k === "⌫" ? "bg-destructive text-destructive-foreground" : "bg-accent"}`}>{k}</button>
            ))}
          </div>
        </div>
      )}

      {tab === "formula" && <FormulaHelper />}
      {tab === "convert" && <UnitConverter />}

      {history.length > 0 && (
        <div className="card-soft p-4">
          <h3 className="mb-2 text-xs font-semibold uppercase text-muted-foreground">History</h3>
          <ul className="space-y-1 text-sm">{history.map((h, i) => <li key={i} className="text-muted-foreground">{h}</li>)}</ul>
        </div>
      )}
    </div>
  );
}

function FormulaHelper() {
  const [q, setQ] = useState("");
  const [ans, setAns] = useState("");
  const [loading, setLoading] = useState(false);
  async function ask() {
    if (!q) return;
    setLoading(true);
    const res = await askAI(`Explain this formula or concept clearly. Include: 1) the formula, 2) what each variable means, 3) one example. Question: ${q}`);
    setAns(res.text); setLoading(false);
  }
  return (
    <div className="card-soft mx-auto max-w-2xl space-y-3 p-4">
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder='e.g. "Formula for kinetic energy"' className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm" />
      <button onClick={ask} disabled={loading} className="w-full rounded-lg bg-primary py-2 text-sm font-semibold text-primary-foreground disabled:opacity-50">
        {loading ? <><Loader2 className="mr-2 inline h-4 w-4 animate-spin" /> Thinking…</> : "Ask"}
      </button>
      {ans && <div className="whitespace-pre-wrap rounded-lg bg-accent p-3 text-sm">{ans}</div>}
    </div>
  );
}

function UnitConverter() {
  const UNITS = {
    Length: { m: 1, km: 1000, cm: 0.01, mm: 0.001, mi: 1609.34, ft: 0.3048, in: 0.0254 },
    Weight: { kg: 1, g: 0.001, lb: 0.453592, oz: 0.0283495 },
    Speed: { "m/s": 1, "km/h": 0.277778, mph: 0.44704 },
    Data: { B: 1, KB: 1024, MB: 1048576, GB: 1073741824 },
  } as const;
  const [cat, setCat] = useState<keyof typeof UNITS>("Length");
  const [from, setFrom] = useState("m"); const [to, setTo] = useState("km");
  const [val, setVal] = useState("1");
  const result = cat === "Length" || cat === "Weight" || cat === "Speed" || cat === "Data"
    ? (parseFloat(val) * (UNITS[cat] as Record<string, number>)[from] / (UNITS[cat] as Record<string, number>)[to]).toString()
    : "";
  const tempConvert = () => {
    if (cat !== ("Temperature" as never)) return "";
    return "";
  };
  return (
    <div className="card-soft mx-auto max-w-xl space-y-3 p-4">
      <select value={cat} onChange={(e) => { const c = e.target.value as keyof typeof UNITS; setCat(c); const ks = Object.keys(UNITS[c]); setFrom(ks[0]); setTo(ks[1]); }} className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm">
        {Object.keys(UNITS).map((k) => <option key={k}>{k}</option>)}
      </select>
      <div className="grid grid-cols-2 gap-2">
        <div>
          <input type="number" value={val} onChange={(e) => setVal(e.target.value)} className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm" />
          <select value={from} onChange={(e) => setFrom(e.target.value)} className="mt-1 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm">{Object.keys(UNITS[cat]).map((u) => <option key={u}>{u}</option>)}</select>
        </div>
        <div>
          <input readOnly value={result} className="w-full rounded-lg border border-input bg-accent px-3 py-2 text-sm" />
          <select value={to} onChange={(e) => setTo(e.target.value)} className="mt-1 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm">{Object.keys(UNITS[cat]).map((u) => <option key={u}>{u}</option>)}</select>
        </div>
      </div>
    </div>
  );
}
