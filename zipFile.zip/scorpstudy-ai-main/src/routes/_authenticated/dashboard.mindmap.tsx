import { createFileRoute } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { Loader2, Download, Save, ZoomIn, ZoomOut } from "lucide-react";
import { toast } from "sonner";
import { askAI, extractJSON } from "@/lib/aiProvider";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/dashboard/mindmap")({
  component: MindMapPage,
});

type Node = { label: string; children?: Node[] };

const COLORS = ["#2563EB", "#10B981", "#F59E0B", "#EF4444", "#8B5CF6", "#EC4899", "#06B6D4", "#84CC16"];

function MindMapPage() {
  const { user } = Route.useRouteContext();
  const [topic, setTopic] = useState("");
  const [tree, setTree] = useState<Node | null>(null);
  const [loading, setLoading] = useState(false);
  const [zoom, setZoom] = useState(1);
  const svgRef = useRef<SVGSVGElement>(null);

  async function generate() {
    if (!topic.trim()) return toast.error("Enter a topic");
    setLoading(true);
    const prompt = `Create a mind map for "${topic}". Return STRICT JSON: {"label":"central topic","children":[{"label":"main branch","children":[{"label":"sub"}]}]}. 4-6 main branches, 2-4 sub-branches each.`;
    const res = await askAI(prompt, "JSON only.");
    const parsed = extractJSON<Node>(res.text);
    if (parsed) setTree(parsed); else toast.error("Could not parse mind map");
    setLoading(false);
  }

  async function save() {
    if (!tree) return;
    const { error } = await supabase.from("mindmaps").insert({ user_id: user.id, topic, map_data: tree as never });
    if (error) return toast.error(error.message); toast.success("Saved");
  }

  function downloadPNG() {
    if (!svgRef.current) return;
    const svg = svgRef.current;
    const data = new XMLSerializer().serializeToString(svg);
    const img = new Image();
    const canvas = document.createElement("canvas");
    canvas.width = 1200; canvas.height = 800;
    const ctx = canvas.getContext("2d")!;
    img.onload = () => {
      ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0);
      const a = document.createElement("a");
      a.download = `mindmap-${Date.now()}.png`; a.href = canvas.toDataURL("image/png"); a.click();
    };
    img.src = "data:image/svg+xml;base64," + btoa(unescape(encodeURIComponent(data)));
  }

  return (
    <div className="space-y-4">
      <div className="card-soft flex flex-wrap items-center gap-2 p-3">
        <input value={topic} onChange={(e) => setTopic(e.target.value)} placeholder="Topic, e.g. 'Photosynthesis'" className="flex-1 rounded-lg border border-input bg-background px-3 py-2 text-sm" />
        <button onClick={generate} disabled={loading} className="rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-50">
          {loading ? <Loader2 className="inline h-4 w-4 animate-spin" /> : "Generate"}
        </button>
        {tree && <>
          <button onClick={() => setZoom(zoom + 0.1)} className="rounded-md border border-border p-2"><ZoomIn className="h-3 w-3" /></button>
          <button onClick={() => setZoom(Math.max(0.5, zoom - 0.1))} className="rounded-md border border-border p-2"><ZoomOut className="h-3 w-3" /></button>
          <button onClick={downloadPNG} className="flex items-center gap-1 rounded-md border border-border px-2 py-1.5 text-xs"><Download className="h-3 w-3" /> PNG</button>
          <button onClick={save} className="flex items-center gap-1 rounded-md border border-border px-2 py-1.5 text-xs"><Save className="h-3 w-3" /> Save</button>
        </>}
      </div>

      {tree && (
        <div className="card-soft overflow-auto p-4">
          <svg ref={svgRef} viewBox="0 0 1200 800" style={{ width: 1200 * zoom, height: 800 * zoom }}>
            <MindMapRender root={tree} />
          </svg>
        </div>
      )}
    </div>
  );
}

function MindMapRender({ root }: { root: Node }) {
  const cx = 600, cy = 400;
  const branches = root.children ?? [];
  return (
    <g>
      {branches.map((b, i) => {
        const angle = (i / branches.length) * Math.PI * 2;
        const bx = cx + Math.cos(angle) * 250;
        const by = cy + Math.sin(angle) * 220;
        const color = COLORS[i % COLORS.length];
        return (
          <g key={i}>
            <line x1={cx} y1={cy} x2={bx} y2={by} stroke={color} strokeWidth={2} />
            <rect x={bx - 70} y={by - 18} width={140} height={36} rx={18} fill={color} />
            <text x={bx} y={by + 5} textAnchor="middle" fill="white" fontSize={12} fontWeight={600}>{truncate(b.label, 22)}</text>
            {(b.children ?? []).map((c, j) => {
              const subAngle = angle + (j - (b.children!.length - 1) / 2) * 0.35;
              const cxx = bx + Math.cos(subAngle) * 160;
              const cyy = by + Math.sin(subAngle) * 140;
              return (
                <g key={j}>
                  <line x1={bx} y1={by} x2={cxx} y2={cyy} stroke={color} strokeWidth={1.5} opacity={0.5} />
                  <rect x={cxx - 55} y={cyy - 14} width={110} height={28} rx={14} fill="white" stroke={color} strokeWidth={1.5} />
                  <text x={cxx} y={cyy + 4} textAnchor="middle" fill={color} fontSize={11}>{truncate(c.label, 16)}</text>
                </g>
              );
            })}
          </g>
        );
      })}
      <circle cx={cx} cy={cy} r={60} fill="#2563EB" />
      <text x={cx} y={cy + 5} textAnchor="middle" fill="white" fontSize={14} fontWeight={700}>{truncate(root.label, 14)}</text>
    </g>
  );
}
function truncate(s: string, n: number) { return s.length > n ? s.slice(0, n - 1) + "…" : s; }
