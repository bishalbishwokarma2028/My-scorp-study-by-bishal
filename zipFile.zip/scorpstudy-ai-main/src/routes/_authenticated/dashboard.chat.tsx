import { createFileRoute } from "@tanstack/react-router";
import { useState, useRef, useEffect } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { Send, Copy, RefreshCw, Save, Plus, GraduationCap, ImageIcon, Paperclip, User } from "lucide-react";
import { toast } from "sonner";
import { askAI } from "@/lib/aiProvider";
import { supabase } from "@/integrations/supabase/client";
import { AiThinking } from "@/components/ai-ui";
import logoUrl from "@/assets/scorpstudy-logo.png";

export const Route = createFileRoute("/_authenticated/dashboard/chat")({
  component: ChatPage,
});

type Msg = { role: "user" | "assistant"; content: string; provider?: string };

const SYSTEM_PROMPT = `You are Bishal's Assistant — an AI study assistant developed by Bishal Bishwokarma for the ScorpStudy platform.

ALWAYS follow this response format:
1. Begin every NEW conversation with: "Hello Student, I'm an AI assistant developed by Bishal Bishwokarma."
2. Then introduce the topic in 1–2 friendly sentences.
3. Use clear Markdown: numbered lists, bullet points, headings when helpful.
4. Highlight EVERY important keyword, key term, technical word, person, place, formula, or concept by wrapping it in **bold** (double asterisks). These will be rendered as bold + blue + underlined automatically — do not add color codes yourself.
5. Be concise, clear, and educational. Always end with an encouraging line if the answer is long.`;

function ChatPage() {
  const { user } = Route.useRouteContext();
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [mode, setMode] = useState<"topper" | "visual">("topper");
  const [loading, setLoading] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, loading]);
  useEffect(() => { inputRef.current?.focus(); }, []);

  async function send(prompt?: string) {
    const text = (prompt ?? input).trim();
    if (!text || loading) return;
    setInput("");
    const isFirst = messages.length === 0;
    const newMsgs: Msg[] = [...messages, { role: "user", content: text }];
    setMessages(newMsgs);
    setLoading(true);
    const styleHint = mode === "topper"
      ? "Answer like a top-scoring student would — structured, exam-ready, with key terms bolded."
      : "Where possible, describe a visual or diagram in words; suggest a diagram concept the student could draw.";
    const sys = `${SYSTEM_PROMPT}\n\n${styleHint}${isFirst ? "" : "\n\nThis is a follow-up turn in the same conversation — do not repeat the greeting."}`;
    const res = await askAI(text, sys);
    setMessages([...newMsgs, { role: "assistant", content: res.text, provider: res.provider }]);
    setLoading(false);
    setTimeout(() => inputRef.current?.focus(), 50);
  }

  async function saveChat() {
    if (messages.length === 0) return toast.error("Nothing to save");
    const { error } = await supabase.from("chat_history").insert({
      user_id: user.id,
      title: messages[0].content.slice(0, 60),
      subject: "General",
      messages: messages as never,
      provider: messages[messages.length - 1]?.provider ?? null,
    });
    if (error) return toast.error(error.message);
    await supabase.from("user_stats").upsert({ user_id: user.id, total_chats: 1 }, { onConflict: "user_id", ignoreDuplicates: false });
    toast.success("Chat saved to history");
  }

  function newChat() {
    setMessages([]);
    setInput("");
    setTimeout(() => inputRef.current?.focus(), 50);
  }

  return (
    <div className="mx-auto flex h-[calc(100vh-10rem)] max-w-4xl flex-col overflow-hidden rounded-3xl border border-border bg-white shadow-sm">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border px-5 py-3.5">
        <div className="flex items-center gap-3">
          <img src={logoUrl} alt="" width={36} height={36} className="h-9 w-9 rounded-xl object-contain" />
          <h1 className="text-lg font-bold">Bishal's Assistant</h1>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button onClick={() => setMode("topper")} className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-medium transition ${mode === "topper" ? "border-violet-300 bg-violet-50 text-violet-700" : "border-border bg-white text-muted-foreground hover:bg-accent"}`}>
            <GraduationCap className="h-3.5 w-3.5" /> Topper Style
          </button>
          <button onClick={() => setMode("visual")} className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-medium transition ${mode === "visual" ? "border-violet-300 bg-violet-50 text-violet-700" : "border-border bg-white text-muted-foreground hover:bg-accent"}`}>
            <ImageIcon className="h-3.5 w-3.5" /> Visual
          </button>
          <button onClick={newChat} className="inline-flex items-center gap-1.5 rounded-full border border-border bg-white px-3 py-1.5 text-xs font-medium text-muted-foreground hover:bg-accent"><Plus className="h-3.5 w-3.5" /> New</button>
          <button onClick={saveChat} className="inline-flex items-center gap-1.5 rounded-full border border-border bg-white px-3 py-1.5 text-xs font-medium text-muted-foreground hover:bg-accent"><Save className="h-3.5 w-3.5" /> Save</button>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 space-y-5 overflow-y-auto bg-slate-50/50 px-5 py-6">
        {messages.length === 0 && (
          <div className="grid h-full place-items-center text-center text-muted-foreground">
            <div>
              <img src={logoUrl} alt="" width={64} height={64} className="mx-auto h-16 w-16 object-contain opacity-80" />
              <p className="mt-3 text-lg font-semibold text-foreground">Hi! I'm Bishal's Assistant</p>
              <p className="mt-1 max-w-sm text-sm">Ask me anything — math, science, history, coding, languages. I'll explain it like your favorite teacher.</p>
              <div className="mt-4 flex flex-wrap justify-center gap-2">
                {["Explain the Water Cycle", "Solve x² − 5x + 6 = 0", "Photosynthesis in simple words"].map((s) => (
                  <button key={s} onClick={() => send(s)} className="rounded-full border border-border bg-white px-3 py-1.5 text-xs font-medium hover:bg-accent">{s}</button>
                ))}
              </div>
            </div>
          </div>
        )}
        {messages.map((m, i) => (
          <div key={i} className={`flex items-start gap-3 ${m.role === "user" ? "flex-row-reverse" : ""}`}>
            <div className={`grid h-9 w-9 flex-shrink-0 place-items-center rounded-full ${m.role === "user" ? "bg-slate-200 text-slate-600" : "bg-gradient-to-br from-blue-500 to-violet-600 text-white"}`}>
              {m.role === "user" ? <User className="h-4 w-4" /> : <img src={logoUrl} alt="" width={24} height={24} className="h-6 w-6 object-contain" />}
            </div>
            <div className={`max-w-[85%] rounded-2xl px-4 py-3 ${m.role === "user" ? "bg-blue-600 text-white" : "border border-border bg-white text-foreground"}`}>
              {m.role === "user" ? (
                <p className="text-sm font-medium">{m.content}</p>
              ) : (
                <>
                  <div className="prose prose-sm max-w-none text-foreground prose-p:my-2 prose-headings:mt-3 prose-headings:text-foreground prose-li:my-0.5">
                    <ReactMarkdown
                      remarkPlugins={[remarkGfm]}
                      components={{
                        strong: ({ children }) => <strong className="font-bold text-blue-600 underline decoration-blue-400/60 underline-offset-2">{children}</strong>,
                        a: ({ children, href }) => <a href={href} className="text-blue-600 underline">{children}</a>,
                      }}
                    >
                      {m.content}
                    </ReactMarkdown>
                  </div>
                  <div className="mt-2 flex items-center gap-1 text-xs">
                    <button onClick={() => { navigator.clipboard.writeText(m.content); toast.success("Copied"); }} className="rounded p-1 text-muted-foreground hover:bg-accent" title="Copy"><Copy className="h-3 w-3" /></button>
                    {i === messages.length - 1 && (
                      <button onClick={() => { setMessages(messages.slice(0, -1)); send(messages[messages.length - 2]?.content); }} className="ml-auto inline-flex items-center gap-1 rounded p-1 text-muted-foreground hover:bg-accent"><RefreshCw className="h-3 w-3" /> Regenerate</button>
                    )}
                  </div>
                </>
              )}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex items-start gap-3">
            <div className="grid h-9 w-9 place-items-center rounded-full bg-gradient-to-br from-blue-500 to-violet-600 text-white"><img src={logoUrl} alt="" width={24} height={24} className="h-6 w-6 object-contain" /></div>
            <div className="rounded-2xl border border-border bg-white px-4 py-3"><AiThinking /></div>
          </div>
        )}
        <div ref={endRef} />
      </div>

      {/* Composer */}
      <form onSubmit={(e) => { e.preventDefault(); send(); }} className="border-t border-border bg-white px-4 py-3">
        <div className="flex items-end gap-2 rounded-2xl border border-border bg-white px-3 py-2 focus-within:border-violet-400 focus-within:ring-2 focus-within:ring-violet-200">
          <button type="button" className="rounded-md p-2 text-muted-foreground hover:bg-accent" title="Attach (coming soon)"><Paperclip className="h-4 w-4" /></button>
          <textarea
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
            placeholder="Ask your question... (Enter to send, Shift+Enter for new line)"
            rows={1}
            className="flex-1 resize-none border-none bg-transparent py-2 text-sm outline-none"
          />
          <button disabled={loading || !input.trim()} className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-blue-600 to-violet-600 text-white shadow-md hover:opacity-90 disabled:opacity-40">
            <Send className="h-4 w-4" />
          </button>
        </div>
        <div className="mt-1.5 flex items-center justify-between px-2 text-[11px] text-muted-foreground">
          <span>Attach images or documents • Select text → Visual to generate diagram</span>
          <span className="text-emerald-600">✓ Auto-saved to history</span>
        </div>
      </form>
    </div>
  );
}
