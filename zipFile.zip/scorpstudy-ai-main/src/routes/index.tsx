import { createFileRoute, Link } from "@tanstack/react-router";
import {
  MessageSquare, FileText, ListChecks, Layers, Image as ImageIcon, BookOpen, Camera,
  Sparkles, Globe, Clock, Star, Shield, ArrowRight, Calculator as CalcIcon, FlaskConical,
  Atom, History as HistoryIcon, Code2, Languages as LangIcon, BarChart3, Music, Palette,
  CheckCircle2, XCircle, Zap, TrendingUp, Brain,
} from "lucide-react";
import logoUrl from "@/assets/scorpstudy-logo.png";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ScorpStudy by Bishal — Study Smarter with AI" },
      { name: "description", content: "Your personal AI companion for every student. Ask questions, solve problems, create quizzes, summarize textbooks, make flashcards — all in one place." },
      { property: "og:title", content: "ScorpStudy by Bishal" },
      { property: "og:description", content: "Bishal's AI Learning Platform. 60+ languages. 24/7. Free." },
    ],
  }),
  component: Landing,
});

const features = [
  { icon: MessageSquare, title: "Bishal's AI Assistant", desc: "Chat with a smart tutor that knows everything. Ask about any subject — science, math, history, coding. Get detailed, exam-ready answers in seconds.", color: "from-blue-500 to-cyan-500", badge: "Most Popular" },
  { icon: FileText, title: "PDF Summarizer", desc: "Paste any long text or textbook content. Get a concise summary, key bullet points, and auto-generated exam questions instantly.", color: "from-violet-500 to-purple-500" },
  { icon: ListChecks, title: "Quiz Generator", desc: "Test yourself with AI-crafted quizzes on any topic. Choose difficulty and question count. No two quizzes are the same — endless practice.", color: "from-fuchsia-500 to-purple-500" },
  { icon: Layers, title: "Flashcard Maker", desc: "Type your topic and get beautifully designed flashcards in seconds. Flip through them to memorize faster. Built for spaced repetition learning.", color: "from-pink-500 to-rose-500" },
  { icon: Camera, title: "Image Question Solver", desc: "Snap a photo of any question paper, textbook page, or worksheet. The AI reads it, identifies every question, and solves them step by step.", color: "from-rose-500 to-pink-600", badge: "New" },
  { icon: BookOpen, title: "Smart Notes", desc: "Write notes and let AI enhance them, add structure, fix grammar, and create summaries. Export to PDF or generate a quiz straight from your notes.", color: "from-red-500 to-rose-500" },
];

const subjects = [
  { name: "Mathematics", icon: CalcIcon, color: "bg-blue-100 text-blue-700" },
  { name: "Physics", icon: Atom, color: "bg-purple-100 text-purple-700" },
  { name: "Chemistry", icon: FlaskConical, color: "bg-green-100 text-green-700" },
  { name: "Biology", icon: Brain, color: "bg-emerald-100 text-emerald-700" },
  { name: "Programming", icon: Code2, color: "bg-indigo-100 text-indigo-700" },
  { name: "History", icon: HistoryIcon, color: "bg-amber-100 text-amber-700" },
  { name: "Geography", icon: Globe, color: "bg-teal-100 text-teal-700" },
  { name: "Languages", icon: LangIcon, color: "bg-pink-100 text-pink-700" },
  { name: "Economics", icon: BarChart3, color: "bg-orange-100 text-orange-700" },
  { name: "Literature", icon: BookOpen, color: "bg-violet-100 text-violet-700" },
  { name: "Music Theory", icon: Music, color: "bg-red-100 text-red-700" },
  { name: "Arts & Design", icon: Palette, color: "bg-fuchsia-100 text-fuchsia-700" },
];

function Landing() {
  return (
    <div className="min-h-screen bg-background">
      {/* Navbar */}
      <header className="sticky top-0 z-50 border-b border-border/60 bg-background/80 backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6">
          <Link to="/" className="flex items-center gap-2.5 font-bold">
            <img src={logoUrl} alt="ScorpStudy" width={40} height={40} className="h-10 w-10 object-contain" />
            <div className="leading-tight">
              <div className="text-base">ScorpStudy</div>
              <div className="text-xs font-medium text-primary">by Bishal</div>
            </div>
          </Link>
          <div className="flex items-center gap-3">
            <Link to="/auth" className="rounded-lg px-3 py-2 text-sm font-medium text-muted-foreground hover:text-foreground">Sign In</Link>
            <Link to="/auth" search={{ mode: "signup" }} className="rounded-full bg-gradient-to-r from-blue-600 to-violet-600 px-5 py-2 text-sm font-semibold text-white shadow-lg shadow-violet-500/30 hover:opacity-90">Get Started Free</Link>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10 bg-gradient-to-b from-violet-50 via-white to-white" />
        <div className="mx-auto max-w-5xl px-4 py-20 text-center sm:px-6 sm:py-28">
          <div className="relative mx-auto h-32 w-32">
            <img src={logoUrl} alt="ScorpStudy logo" width={256} height={256} className="h-full w-full object-contain" />
            <span className="absolute -top-1 -right-1 grid h-9 w-9 place-items-center rounded-full bg-gradient-to-br from-violet-600 to-fuchsia-600 text-white shadow-lg">
              <Sparkles className="h-4 w-4" />
            </span>
          </div>
          <div className="mt-6 inline-flex items-center gap-2 rounded-full border border-violet-200 bg-violet-50 px-4 py-1.5 text-xs font-semibold text-violet-700">
            <Zap className="h-3.5 w-3.5" /> Bishal's AI Learning Platform
          </div>
          <h1 className="mt-6 text-5xl font-bold tracking-tight sm:text-7xl">
            Study Smarter with<br />
            <span className="bg-gradient-to-r from-violet-600 to-fuchsia-600 bg-clip-text text-transparent">ScorpStudy</span>
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg text-muted-foreground">
            Your personal AI companion for every student. Ask questions, solve problems, create quizzes, summarize textbooks, make flashcards — all in one place. In any language. For free.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Link to="/auth" search={{ mode: "signup" }} className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-violet-600 to-fuchsia-600 px-7 py-3.5 text-sm font-semibold text-white shadow-xl shadow-violet-500/30 hover:opacity-90">
              Get Started Free <ArrowRight className="h-4 w-4" />
            </Link>
            <Link to="/auth" className="rounded-full border border-border bg-white px-7 py-3.5 text-sm font-semibold hover:bg-accent">Sign In</Link>
          </div>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-6 text-sm text-muted-foreground">
            <span className="inline-flex items-center gap-1.5"><Shield className="h-4 w-4 text-emerald-600" /> No credit card required</span>
            <span className="inline-flex items-center gap-1.5"><Globe className="h-4 w-4 text-violet-600" /> 60+ languages supported</span>
            <span className="inline-flex items-center gap-1.5"><Clock className="h-4 w-4 text-fuchsia-600" /> Setup in 30 seconds</span>
          </div>
        </div>
      </section>

      {/* Stat band */}
      <section className="bg-gradient-to-r from-violet-600 to-indigo-700 text-white">
        <div className="mx-auto grid max-w-5xl grid-cols-1 gap-8 px-4 py-16 sm:grid-cols-3 sm:px-6">
          {[
            { icon: Globe, n: "60+", l: "Supported Languages" },
            { icon: Clock, n: "24/7", l: "Always Available" },
            { icon: Star, n: "Free", l: "To Get Started" },
          ].map((s) => (
            <div key={s.l} className="text-center">
              <div className="mx-auto mb-3 grid h-12 w-12 place-items-center rounded-xl bg-white/15"><s.icon className="h-6 w-6" /></div>
              <div className="text-5xl font-bold tracking-tight">{s.n}</div>
              <div className="mt-1 text-sm opacity-90">{s.l}</div>
            </div>
          ))}
        </div>
      </section>

      {/* How it works */}
      <section className="bg-slate-50 py-20">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <div className="text-center">
            <div className="text-xs font-bold tracking-widest text-violet-600">HOW IT WORKS</div>
            <h2 className="mt-2 text-3xl font-bold sm:text-4xl">Start learning in 3 simple steps</h2>
            <p className="mx-auto mt-3 max-w-xl text-muted-foreground">No complex setup. No learning curve. Just sign up and start studying smarter from day one.</p>
          </div>
          <div className="relative mt-14 grid gap-6 sm:grid-cols-3">
            {[
              { i: Zap, n: "01", t: "Sign Up Free", d: "Create your account in under 30 seconds. No credit card required. Set up your learning profile — level, goals, preferred language.", color: "bg-violet-100 text-violet-700" },
              { i: Brain, n: "02", t: "Personalize Your AI", d: "Tell ScorpStudy your study level, goals, and preferred language. The AI adapts every response to suit you perfectly.", color: "bg-blue-100 text-blue-700" },
              { i: TrendingUp, n: "03", t: "Study Smarter", d: "Use all 6 AI-powered tools together. Chat, quiz yourself, make notes, summarize content, and track your progress daily.", color: "bg-emerald-100 text-emerald-700" },
            ].map((s, i, arr) => (
              <div key={s.n} className="relative rounded-2xl border border-border bg-white p-7 shadow-sm">
                <div className="flex items-start justify-between">
                  <div className={`grid h-12 w-12 place-items-center rounded-xl ${s.color}`}><s.i className="h-6 w-6" /></div>
                  <span className="text-4xl font-bold text-muted-foreground/20">{s.n}</span>
                </div>
                <h3 className="mt-5 text-lg font-semibold">{s.t}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{s.d}</p>
                {i < arr.length - 1 && <ArrowRight className="absolute -right-3 top-1/2 hidden h-6 w-6 -translate-y-1/2 text-muted-foreground/40 sm:block" />}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="mx-auto max-w-7xl px-4 py-20 sm:px-6">
        <div className="text-center">
          <h2 className="text-3xl font-bold sm:text-4xl">Everything you need to ace your exams</h2>
          <p className="mx-auto mt-3 max-w-2xl text-muted-foreground">Six powerful AI tools built specifically for students — from school to university, in any subject.</p>
        </div>
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((f) => (
            <div key={f.title} className="relative rounded-2xl border border-border bg-white p-7 shadow-sm transition hover:shadow-lg">
              {f.badge && (
                <span className={`absolute right-5 top-5 rounded-full px-2.5 py-0.5 text-[10px] font-semibold ${f.badge === "New" ? "bg-emerald-100 text-emerald-700" : "bg-violet-100 text-violet-700"}`}>{f.badge}</span>
              )}
              <div className={`mb-5 grid h-12 w-12 place-items-center rounded-xl bg-gradient-to-br ${f.color} text-white shadow-md`}><f.icon className="h-6 w-6" /></div>
              <h3 className="text-lg font-semibold">{f.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Subjects */}
      <section className="bg-violet-50/60 py-20">
        <div className="mx-auto max-w-6xl px-4 text-center sm:px-6">
          <div className="text-xs font-bold tracking-widest text-violet-600">SUBJECT COVERAGE</div>
          <h2 className="mt-2 text-3xl font-bold sm:text-4xl">Every subject. Every level.</h2>
          <p className="mx-auto mt-3 max-w-2xl text-muted-foreground">Whether you're studying for SEE, +2, Bachelor's, or a Master's degree — ScorpStudy covers every subject you need.</p>
          <div className="mt-10 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
            {subjects.map((s) => (
              <div key={s.name} className={`rounded-2xl p-5 ${s.color}`}>
                <s.icon className="mx-auto h-6 w-6" />
                <div className="mt-2 text-sm font-semibold">{s.name}</div>
              </div>
            ))}
          </div>
          <div className="mx-auto mt-8 max-w-3xl rounded-2xl border border-border bg-white p-6 text-sm">
            <span className="font-semibold text-violet-700">And much more!</span>{" "}
            <span className="text-muted-foreground">The AI can help with any topic — Accounting, Law, Medicine, Psychology, Engineering, Architecture, and every other subject. If you can ask it, ScorpStudy can answer it.</span>
          </div>
        </div>
      </section>

      {/* Old way vs ScorpStudy */}
      <section className="mx-auto max-w-6xl px-4 py-20 sm:px-6">
        <div className="text-center">
          <div className="text-xs font-bold tracking-widest text-violet-600">THE DIFFERENCE</div>
          <h2 className="mt-2 text-3xl font-bold sm:text-4xl">Old way vs. ScorpStudy</h2>
          <p className="mx-auto mt-3 max-w-2xl text-muted-foreground">See why thousands of students are switching to a smarter way to study.</p>
        </div>
        <div className="mt-12 grid gap-6 lg:grid-cols-2">
          <div className="rounded-2xl border border-rose-200 bg-rose-50/60 p-7">
            <div className="flex items-center gap-2 text-rose-700"><XCircle className="h-5 w-5" /><h3 className="text-lg font-bold">Old Way of Studying</h3></div>
            <ul className="mt-5 space-y-3 text-sm text-rose-800/90">
              {["Hours reading the same textbook page","Making flashcards by hand — one by one","Guessing what might be on the exam","Stuck on a question with no help available","Notes that are hard to understand later","Can't afford expensive tutors or apps"].map((t) => (
                <li key={t} className="flex gap-2"><XCircle className="mt-0.5 h-4 w-4 flex-shrink-0 text-rose-500" /> {t}</li>
              ))}
            </ul>
          </div>
          <div className="rounded-2xl border border-emerald-200 bg-emerald-50/60 p-7">
            <div className="flex items-center gap-2 text-emerald-700"><CheckCircle2 className="h-5 w-5" /><h3 className="text-lg font-bold">With ScorpStudy</h3></div>
            <ul className="mt-5 space-y-3 text-sm text-emerald-800/90">
              {["Summarize any text in seconds","Generate 10 flashcards in one click","AI creates custom practice quizzes for you","Get step-by-step help 24/7, any subject","AI enhances and structures your notes automatically","Completely free — no paywalls"].map((t) => (
                <li key={t} className="flex gap-2"><CheckCircle2 className="mt-0.5 h-4 w-4 flex-shrink-0 text-emerald-600" /> {t}</li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-5xl px-4 pb-20 sm:px-6">
        <div className="rounded-3xl bg-gradient-to-br from-violet-600 to-fuchsia-600 px-8 py-14 text-center text-white shadow-2xl shadow-violet-500/30">
          <h2 className="text-3xl font-bold sm:text-4xl">Ready to study smarter?</h2>
          <p className="mx-auto mt-3 max-w-xl opacity-90">Join thousands of students using ScorpStudy by Bishal to ace their exams.</p>
          <Link to="/auth" search={{ mode: "signup" }} className="mt-7 inline-flex items-center gap-2 rounded-full bg-white px-7 py-3.5 text-sm font-semibold text-violet-700 hover:opacity-90">
            Get Started Free <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>

      <footer className="border-t border-border/60 py-8 text-center text-sm text-muted-foreground">
        <p><span className="font-semibold text-foreground">ScorpStudy by Bishal</span> — Built for students.</p>
        <p className="mt-1 text-xs">© {new Date().getFullYear()} ScorpStudy. All rights reserved.</p>
      </footer>
    </div>
  );
}
