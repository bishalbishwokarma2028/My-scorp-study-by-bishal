import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const Input = z.object({
  prompt: z.string().min(1).max(50000),
  systemPrompt: z.string().max(4000).optional(),
});

type Result = { text: string; provider: string };

async function tryGroq(prompt: string, system: string, key: string, label: string): Promise<Result | null> {
  try {
    const res = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
      body: JSON.stringify({
        model: "llama-3.1-8b-instant",
        messages: [
          { role: "system", content: system },
          { role: "user", content: prompt },
        ],
        max_tokens: 2048,
      }),
    });
    if (!res.ok) return null;
    const data = await res.json();
    const text = data?.choices?.[0]?.message?.content;
    if (typeof text === "string" && text.trim()) return { text, provider: label };
    return null;
  } catch {
    return null;
  }
}

async function tryGemini(prompt: string, system: string, key: string, label: string): Promise<Result | null> {
  try {
    const res = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${key}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts: [{ text: `${system}\n\n${prompt}` }] }],
        }),
      },
    );
    if (!res.ok) return null;
    const data = await res.json();
    const text = data?.candidates?.[0]?.content?.parts?.[0]?.text;
    if (typeof text === "string" && text.trim()) return { text, provider: label };
    return null;
  } catch {
    return null;
  }
}

async function tryOpenAI(prompt: string, system: string, key: string): Promise<Result | null> {
  try {
    const res = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
      body: JSON.stringify({
        model: "gpt-3.5-turbo",
        messages: [
          { role: "system", content: system },
          { role: "user", content: prompt },
        ],
        max_tokens: 2048,
      }),
    });
    if (!res.ok) return null;
    const data = await res.json();
    const text = data?.choices?.[0]?.message?.content;
    if (typeof text === "string" && text.trim()) return { text, provider: "OpenAI GPT-3.5" };
    return null;
  } catch {
    return null;
  }
}

async function tryHuggingFace(prompt: string, system: string, key: string): Promise<Result | null> {
  try {
    const res = await fetch(
      "https://api-inference.huggingface.co/models/mistralai/Mistral-7B-Instruct-v0.1",
      {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
        body: JSON.stringify({
          inputs: `${system}\n\n${prompt}`,
          parameters: { max_new_tokens: 1024 },
        }),
      },
    );
    if (!res.ok) return null;
    const data = await res.json();
    const text = Array.isArray(data) ? data[0]?.generated_text : null;
    if (typeof text === "string" && text.trim()) return { text, provider: "HuggingFace Mistral" };
    return null;
  } catch {
    return null;
  }
}

export const askAIServer = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => Input.parse(d))
  .handler(async ({ data }): Promise<Result> => {
    const system =
      data.systemPrompt ?? "You are a helpful AI study assistant called ScorpStudy by Bishal.";

    const groqKeys = [1, 2, 3, 4, 5]
      .map((i) => ({ key: process.env[`GROQ_API_KEY_${i}`], label: `Groq LLaMA 3 (key ${i})` }))
      .filter((x): x is { key: string; label: string } => !!x.key);
    for (const { key, label } of groqKeys) {
      const r = await tryGroq(data.prompt, system, key, label);
      if (r) return r;
    }

    const geminiKeys = [1, 2, 3, 4, 5]
      .map((i) => ({ key: process.env[`GEMINI_API_KEY_${i}`], label: `Gemini 1.5 Flash (key ${i})` }))
      .filter((x): x is { key: string; label: string } => !!x.key);
    for (const { key, label } of geminiKeys) {
      const r = await tryGemini(data.prompt, system, key, label);
      if (r) return r;
    }

    const openaiKey = process.env.OPENAI_API_KEY;
    if (openaiKey) {
      const r = await tryOpenAI(data.prompt, system, openaiKey);
      if (r) return r;
    }

    const hfKey = process.env.HUGGINGFACE_API_KEY;
    if (hfKey) {
      const r = await tryHuggingFace(data.prompt, system, hfKey);
      if (r) return r;
    }

    return {
      text: "AI is busy right now, please try again in a moment.",
      provider: "none",
    };
  });
